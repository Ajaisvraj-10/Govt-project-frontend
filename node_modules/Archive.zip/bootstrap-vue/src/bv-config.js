//
// Utility Plugin for setting the configuration
//
import { pluginFactory } from './utils/plugins'

export const BVConfigPlugin = /*#__PURE__*/ pluginFactory()
