const identity = x => x

export default identity
