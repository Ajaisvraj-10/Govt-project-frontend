//
// Single point of contact for Vue
//
// TODO:
//   Conditionally import Vue if no global Vue
//
import Vue from 'vue'

export default Vue
