//
// VBScrollspy
//
import Vue, { DirectiveOptions } from 'vue'
import { BvPlugin } from '../../'

// Plugin
export declare const VBScrollspyPlugin: BvPlugin

// directive: v-b-scrollspy
export declare const VBScrollspy: DirectiveOptions
