//
// VBToggle
//
import Vue, { DirectiveOptions } from 'vue'
import { BvPlugin } from '../../'

// Plugin
export declare const VBTogglePlugin: BvPlugin

// directive: v-b-toggle
export declare const VBToggle: DirectiveOptions
