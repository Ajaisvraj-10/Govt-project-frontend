//
// VBVisible
//
import Vue, { DirectiveOptions } from 'vue'
import { BvPlugin } from '../../'

// Plugin
export declare const VBVisiblePlugin: BvPlugin

// Directive: v-b-visible
export declare const VBVisible: DirectiveOptions
