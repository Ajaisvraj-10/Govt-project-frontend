//
// VBHover
//
import Vue, { DirectiveOptions } from 'vue'
import { BvPlugin } from '../../'

// Plugin
export declare const VBHoverPlugin: BvPlugin

// directive: v-b-hover
export declare const VBHover: DirectiveOptions
