//
// VBTooltip
//
import Vue, { DirectiveOptions } from 'vue'
import { BvPlugin } from '../../'

// Plugin
export declare const VBTooltipPlugin: BvPlugin

// directive: v-b-tooltip
export declare const VBTooltip: DirectiveOptions
