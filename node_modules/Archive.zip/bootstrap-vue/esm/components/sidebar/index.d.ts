//
// Sidebar
//
import Vue from 'vue'
import { BvPlugin, BvComponent } from '../../'

// Plugin
export declare const SidebarPlugin: BvPlugin

// Component: b-sidebar
export declare class BSidebar extends BvComponent {}
