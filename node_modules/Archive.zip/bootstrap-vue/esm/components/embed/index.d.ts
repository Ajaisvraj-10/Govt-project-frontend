//
// Embed
//
import Vue from 'vue'
import { BvPlugin, BvComponent } from '../../'

// Plugin
export declare const EmbedPlugin: BvPlugin

// Component: b-embed
export declare class BEmbed extends BvComponent {}
