//
// Aspect
//
import Vue from 'vue'
import { BvPlugin, BvComponent } from '../../'

// Plugin
export declare const AspectPlugin: BvPlugin

// Component: b-aspect
export declare class BAspect extends BvComponent {}
