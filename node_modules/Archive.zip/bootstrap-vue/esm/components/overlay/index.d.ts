//
// Overlay
//
import Vue from 'vue'
import { BvPlugin, BvComponent } from '../../'

// Plugin
export declare const OverlayPlugin: BvPlugin

// Component: b-overlay
export declare class BOverlay extends BvComponent {}
