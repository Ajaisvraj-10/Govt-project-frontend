//
// Spinner
//
import Vue from 'vue'
import { BvPlugin, BvComponent } from '../../'

// Plugin
export declare const SpinnerPlugin: BvPlugin

// Component: b-alert
export declare class BSpinner extends BvComponent {}
