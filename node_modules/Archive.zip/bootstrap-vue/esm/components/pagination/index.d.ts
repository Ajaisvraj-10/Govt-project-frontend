//
// Pagination
//
import Vue from 'vue'
import { BvPlugin, BvComponent } from '../../'

// Plugin
export declare const PaginationPlugin: BvPlugin

// Component: b-pagination
export declare class BPagination extends BvComponent {}
